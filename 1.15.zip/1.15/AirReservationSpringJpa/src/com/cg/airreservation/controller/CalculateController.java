package com.cg.airreservation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.service.ICalculateService;

@Controller
@Scope("session")
public class CalculateController {

	@Autowired
	ICalculateService service;
	
	
	
	/**
	 * this method is used for calculating fare while customer book tickets
	 * @param type is class type for which customer want to book tickets
	 * @param totalSeat is number of seats customer want to book
	 * @param selectedFlight is flight in which customer want to book tickets 
	 * @param userEmail	is customer email
	 * @param model
	 * @return
	 */
	@RequestMapping("/calculate")
	public String calculate(@ModelAttribute("type") String type,@ModelAttribute("totalSeat") int totalSeat,@ModelAttribute("flightInfo") Flightinfo selectedFlight,@ModelAttribute("custEmail") String userEmail,Model model)
	{
		double totalFare=0.0;
		try {
			totalFare=service.calculateFare(selectedFlight, type, totalSeat);
		} catch (AirlineException e) {
			model.addAttribute("email", userEmail);
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		model.addAttribute("type", type);
		model.addAttribute("flightInfo", selectedFlight);
		model.addAttribute("totalFare", totalFare);
		model.addAttribute("email", userEmail);
		model.addAttribute("bookingDetail", new Bookinginfo());
		return"displayDetails";
	}
	
	/**
	 * this method is used to calculate total fare while customer updating ticket
	 * @param bookingbean is object in which updated booking details are stored
	 * @param selectedFlight is flight for which customer is updating ticket
	 * @param model
	 * @return
	 */
	@RequestMapping("/calculateModify")
	public String calculateAfterUpdate(@ModelAttribute("updateBean") Bookinginfo bookingbean,@ModelAttribute("flightInfo") Flightinfo selectedFlight,@ModelAttribute("email") String email,Model model)
	{
		double totalFare=0.0;
		
		try {
			totalFare=service.calculateFare(selectedFlight, bookingbean.getClasstype(), bookingbean.getPassengernum());
		} catch (AirlineException e) {
			model.addAttribute("email", email);
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
			}
		model.addAttribute("bookingbean", bookingbean);
		model.addAttribute("flightInfo", selectedFlight);
		model.addAttribute("totalFare", totalFare);
		model.addAttribute("email", email);
		model.addAttribute("bookingInfo", new Bookinginfo());
		return"displayUpdatedDetails";
	}
}
