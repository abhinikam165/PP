package com.cg.airreservation.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.entities.Customerinfo;
import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.service.IBookingService;
import com.cg.airreservation.service.IFlightService;

@Controller
@Scope("session")
public class BookingController {

	@Autowired
	Bookinginfo bookInfo;

	@Autowired
	IBookingService bookService;

	@Autowired
	IFlightService flightService;

	String classType;
	int numOfSeats;
	String emailId;

	/**
	 * this method is used to transfer control customer home page
	 * 
	 * @param email
	 *            is email of logged in user
	 * @param model
	 * @return
	 */
	@RequestMapping("/returnToHome")
	public String returnToHome(@ModelAttribute("custEmail") String email,HttpSession session,
			Model model) {
		
		Customerinfo customerBean = new Customerinfo();
		customerBean.setCustemail(email);
		//session.setAttribute("sessionEmail", email);
		model.addAttribute("Customer", customerBean);
		emailId=email;
		return "customerHome";
	}

	/**
	 * this method is used to book tickets for user add details in bookinginfo
	 * table
	 * 
	 * @param bookingDetail
	 *            is bookinginfo bean in which all booking details are stored
	 * @param model
	 * @return
	 */
	@RequestMapping("/confirm")
	public String confirmBook(Bookinginfo bookingDetail, Model model) {
		boolean confirmBooking;
		model.addAttribute("bookingBean", bookingDetail);
		try {
			confirmBooking = bookService.confirmBooking(bookingDetail);
			if (confirmBooking) {
				int flag = flightService.updateFlightSeats(bookingDetail);
				if (flag == 0)
					throw new AirlineException(
							"Tickets cannot be confirmed.. Please try again later..");
			}
		} catch (AirlineException e) {
			model.addAttribute("email", bookingDetail.getCustomerinfo().getCustemail());
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		return "bookingSuccess";
	}

	
	
	@RequestMapping("/bookingDetails")
	public String bookingDetail(@ModelAttribute("custEmail") String email,
			Model model) {
		try {
			ArrayList<Bookinginfo> fetchAllBooking=bookService.getAllBookingDetails(email);
			model.addAttribute("bookingDetails", fetchAllBooking);
		} catch (AirlineException e) {
			model.addAttribute("email",email );
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		return "showBookingDetails";
	}
	
	
	
	/**
	 * this method is used to get list of all booking by logged in customer
	 * 
	 * @param customerEmail
	 *            is email for logged in customer
	 * @param model
	 * @return
	 */
	@RequestMapping("/modifyBooking")
	public String updateBookingInfo(
			@ModelAttribute("custEmail") String customerEmail, Model model) {
		try {
			ArrayList<Bookinginfo> bookingInfoList = bookService
					.getBookingDetails(customerEmail);
			model.addAttribute("bookingInfoList", bookingInfoList);
		} catch (AirlineException e) {
			model.addAttribute("email", customerEmail);
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		return "modifyBookingList";
	}

	/**
	 * this method is used to get details of particular booking from list shown
	 * to customer
	 * 
	 * @param bookingId
	 *            is id for which customer want to know details
	 * @param model
	 * @return
	 */
	@RequestMapping("bookingListInfo")
	public String getBookingListInfo(@RequestParam("bookingId") int bookingId,
			Model model) {
		try {
			Bookinginfo bookInfo = bookService.fetchBookingDetails(bookingId);
			model.addAttribute("bookingDetails", bookInfo);
			model.addAttribute("book", bookInfo);
		} catch (AirlineException e) {
			model.addAttribute("email", emailId);
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		classType = bookInfo.getClasstype();
		numOfSeats = bookInfo.getPassengernum();
		return "bookingInfo";
	}

	/**
	 * this method is used to check if updated seats are available in flight or
	 * not, if available pass control to calculate controller and calculate
	 * total fare
	 * 
	 * @param updateBookingBean
	 *            is booking bean in which all updated details are stored
	 * @param redirectAttrs
	 *            is reference to RedirectAttributes which is used to pass
	 *            attributes from one controller to another
	 * @param type
	 *            is previous class type for which tickets are already booked
	 * @param totalSeat
	 *            is previous seat booked by customer
	 * @param model
	 * @return
	 */
	
	// TODO write check condition in service or utility
	@RequestMapping("/updateBookingInfo")
	public String updateBookingInfo(
			@ModelAttribute("book") Bookinginfo updateBookingBean,
			RedirectAttributes redirectAttrs,
			@RequestParam("type") String type,
			@RequestParam("numOfSeats") int totalSeat, Model model) {
		Flightinfo updateFlightBean = null;
		System.out.println(updateBookingBean.getFlightinfo().getFlightid());
		try {
			updateFlightBean = flightService
					.fetchFlightDetails(updateBookingBean.getFlightinfo()
							.getFlightid());
		} catch (AirlineException e) {
			model.addAttribute("email", updateBookingBean.getCustomerinfo().getCustemail());
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		redirectAttrs.addFlashAttribute("updateBean", updateBookingBean);
		redirectAttrs.addFlashAttribute("flightInfo", updateFlightBean);
		redirectAttrs.addFlashAttribute("email", updateBookingBean.getCustomerinfo().getCustemail());
		classType = type;
		numOfSeats = totalSeat;
		model.addAttribute("updateMessage",
				"Updated Number of seats are not available");
		if (updateBookingBean.getClasstype().equals(classType)) {
			if (updateBookingBean.getClasstype().equals("Business")) {
				if ((updateFlightBean.getBussseats() + numOfSeats - updateBookingBean
						.getPassengernum()) < 0) {
					try {
						Bookinginfo bookInfo = bookService
								.fetchBookingDetails(updateBookingBean
										.getBookingid());
						model.addAttribute("bookingDetails", bookInfo);
						model.addAttribute("book", bookInfo);
					} catch (AirlineException e) {
						model.addAttribute("email", updateBookingBean.getCustomerinfo().getCustemail());
						model.addAttribute("flag", "customer");
						model.addAttribute("errorMessage", e.getMessage());
						return "errorPage";
					}
					return "bookingInfo";
				}
			} else if (updateBookingBean.getClasstype().equals("Economy")) {
				if ((updateFlightBean.getEcoseats() + numOfSeats - updateBookingBean
						.getPassengernum()) < 0) {
					try {
						Bookinginfo bookInfo = bookService
								.fetchBookingDetails(updateBookingBean
										.getBookingid());
						model.addAttribute("bookingDetails", bookInfo);
						model.addAttribute("book", bookInfo);
					} catch (AirlineException e) {
						model.addAttribute("email", updateBookingBean.getCustomerinfo().getCustemail());
						model.addAttribute("flag", "customer");
						model.addAttribute("errorMessage", e.getMessage());
						return "errorPage";
					}
					return "bookingInfo";
				}

			}
		}
		// different class type
		else {
			if (updateBookingBean.getClasstype().equals("Business")) {
				if ((updateFlightBean.getBussseats() - updateBookingBean
						.getPassengernum()) < 0) {
					try {
						Bookinginfo bookInfo = bookService
								.fetchBookingDetails(updateBookingBean
										.getBookingid());
						model.addAttribute("bookingDetails", bookInfo);
						model.addAttribute("book", bookInfo);
					} catch (AirlineException e) {
						model.addAttribute("email", updateBookingBean.getCustomerinfo().getCustemail());
						model.addAttribute("flag", "customer");
						model.addAttribute("errorMessage", e.getMessage());
						return "errorPage";
					}
					return "bookingInfo";
				}
			} else if (updateBookingBean.getClasstype().equals("Economy")) {
				if ((updateFlightBean.getEcoseats() - updateBookingBean
						.getPassengernum()) < 0) {
					try {
						Bookinginfo bookInfo = bookService
								.fetchBookingDetails(updateBookingBean
										.getBookingid());
						model.addAttribute("bookingDetails", bookInfo);
						model.addAttribute("book", bookInfo);
					} catch (AirlineException e) {
						model.addAttribute("email", updateBookingBean.getCustomerinfo().getCustemail());
						model.addAttribute("flag", "customer");
						model.addAttribute("errorMessage", e.getMessage());
						return "errorPage";
					}
					return "bookingInfo";
				}
			}
		}

		return "redirect:/calculateModify.obj";
	}

	/**
	 * this method is used to cancel booking based on booking id
	 * 
	 * @param bookingId
	 *            is id for which user want to delete ticket
	 * @param model
	 * @return
	 */
	@RequestMapping("/cancelBookingInfo")
	public String cancelBookingInfo(@RequestParam("bookingId") int bookingId,
			Model model) {
		try {
			Bookinginfo getBookingBean = bookService
					.fetchBookingDetails(bookingId);

			boolean cancelFlag = bookService.cancelBooking(bookingId);
			model.addAttribute("email", getBookingBean.getCustomerinfo()
					.getCustemail());
			if (cancelFlag) {
				int updatedRows = flightService
						.modifyFlightAfterCancel(getBookingBean);
				if (updatedRows == 0)
					throw new AirlineException(
							"Tickets cannot be cancelled.. Please try again later..");
			}
		} catch (AirlineException e) {
			model.addAttribute("email", emailId);
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		return "cancelSuccess";
	}

	/**
	 * this method is used to update booking info and display updated or not
	 * 
	 * @param bookDetails
	 *            is bookinginfo bean object which need to be updated
	 * @param model
	 * @return
	 */
	@RequestMapping("confirmUpdate")
	public String updateBooking(Bookinginfo bookDetails, Model model) {
		Bookinginfo bookingBean = new Bookinginfo();
		bookingBean.setClasstype(classType);
		bookingBean.setPassengernum(numOfSeats);
		try {
			boolean confirmFlag = bookService.updateBooking(bookDetails);
			int updatedRows = flightService.modifyFlightAfterUpdate(
					bookDetails, bookingBean);
			if (!confirmFlag && updatedRows == 0)
				throw new AirlineException(
						"Booking Cannot be updated.. Plesae try again later..");
		} catch (AirlineException e) {
			model.addAttribute("email", bookDetails.getCustomerinfo().getCustemail());
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		model.addAttribute("email", bookDetails.getCustomerinfo()
				.getCustemail());
		return "updateSuccess";
	}
}
