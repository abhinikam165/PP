package com.cg.airreservation.entities;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

/**
 * The persistent class for the FLIGHTINFO database table.
 * 
 */
@Component
@Entity
@Table(name = "FLIGHTINFO")
@NamedQuery(name = "Flightinfo.findAll", query = "SELECT f FROM Flightinfo f")
public class Flightinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, precision = 10)
	@SequenceGenerator(name = "flightidSeq", sequenceName = "seqflightId", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "flightidSeq")
	private long flightid;

	private Date arrdate;

	@NotEmpty(message = "Arrival time is required")
	@Column(length = 13)
	private String arrtime;

	@Column(precision = 10, scale = 2)
	private double bussfare;

	@Column(precision = 4)
	private int bussseats;

	@NotEmpty(message = "Departure time is required")
	@Column(length = 13)
	private String departtime;

	private Date deptdate;

	@Column(length = 20)
	private String destinationcity;

	@Column(precision = 10, scale = 2)
	private double ecofare;

	@Column(precision = 4)
	private int ecoseats;

	@NotEmpty(message = "Flight Number required")
	@Column(length = 5)
	private String flightnum;

	@Column(precision = 4)
	private int rembussseat;

	@Column(precision = 4)
	private int remecoseat;

	@Column(length = 20)
	private String sourcecity;

	// bi-directional many-to-one association to Bookinginfo
	@OneToMany(mappedBy = "flightinfo")
	private List<Bookinginfo> bookinginfos;

	// bi-directional many-to-one association to Airportinfo
	@ManyToOne
	@JoinColumn(name = "AIRLINENAME")
	private Airportinfo airportinfo;

	public Flightinfo() {
	}

	public long getFlightid() {
		return this.flightid;
	}

	public void setFlightid(long flightid) {
		this.flightid = flightid;
	}

	public Date getArrdate() {
		return this.arrdate;
	}

	public void setArrdate(Date arrdate) {
		this.arrdate = arrdate;
	}

	public String getArrtime() {
		return this.arrtime;
	}

	public void setArrtime(String arrtime) {
		this.arrtime = arrtime;
	}

	public double getBussfare() {
		return this.bussfare;
	}

	public void setBussfare(double bussfare) {
		this.bussfare = bussfare;
	}

	public int getBussseats() {
		return this.bussseats;
	}

	public void setBussseats(int bussseats) {
		this.bussseats = bussseats;
	}

	public String getDeparttime() {
		return this.departtime;
	}

	public void setDeparttime(String departtime) {
		this.departtime = departtime;
	}

	public Date getDeptdate() {
		return this.deptdate;
	}

	public void setDeptdate(Date deptdate) {
		this.deptdate = deptdate;
	}

	public String getDestinationcity() {
		return this.destinationcity;
	}

	public void setDestinationcity(String destinationcity) {
		this.destinationcity = destinationcity;
	}

	public double getEcofare() {
		return this.ecofare;
	}

	public void setEcofare(double ecofare) {
		this.ecofare = ecofare;
	}

	public int getEcoseats() {
		return this.ecoseats;
	}

	public void setEcoseats(int ecoseats) {
		this.ecoseats = ecoseats;
	}

	public String getFlightnum() {
		return this.flightnum;
	}

	public void setFlightnum(String flightnum) {
		this.flightnum = flightnum;
	}

	public int getRembussseat() {
		return this.rembussseat;
	}

	public void setRembussseat(int rembussseat) {
		this.rembussseat = rembussseat;
	}

	public int getRemecoseat() {
		return this.remecoseat;
	}

	public void setRemecoseat(int remecoseat) {
		this.remecoseat = remecoseat;
	}

	public String getSourcecity() {
		return this.sourcecity;
	}

	public void setSourcecity(String sourcecity) {
		this.sourcecity = sourcecity;
	}

	public List<Bookinginfo> getBookinginfos() {
		return this.bookinginfos;
	}

	public void setBookinginfos(List<Bookinginfo> bookinginfos) {
		this.bookinginfos = bookinginfos;
	}

	public Bookinginfo addBookinginfo(Bookinginfo bookinginfo) {
		getBookinginfos().add(bookinginfo);
		bookinginfo.setFlightinfo(this);

		return bookinginfo;
	}

	public Bookinginfo removeBookinginfo(Bookinginfo bookinginfo) {
		getBookinginfos().remove(bookinginfo);
		bookinginfo.setFlightinfo(null);

		return bookinginfo;
	}

	public Airportinfo getAirportinfo() {
		return this.airportinfo;
	}

	public void setAirportinfo(Airportinfo airportinfo) {
		this.airportinfo = airportinfo;
	}

}